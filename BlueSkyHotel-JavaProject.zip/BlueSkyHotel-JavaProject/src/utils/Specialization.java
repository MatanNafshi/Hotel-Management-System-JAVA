package utils;

public enum Specialization {
	
	Finance ,Advertisement ,Logistics ,Administration ,costumerService

}
